package com.carpool.controler;

import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carpool.repository.Carpool;
import com.carpool.service.CarpoolServcie;
import com.carpool.util.BaseReponse;
import com.carpool.util.CarpoolConstants;

@RestController
@CrossOrigin(allowCredentials = "true")
public class CarpoolControler {
	@Autowired
	CarpoolServcie service;
	
	private static final Log logger = LogFactory.getLog(CarpoolControler.class);
	
	@GetMapping(CarpoolConstants.SEARCHCAB)
	public BaseReponse searcchCab(@RequestParam("userId") String userId, @RequestParam("StartLocation") String startPoint,
			@RequestParam("endLocation") String endpoint,@RequestParam("DateandTime") Date dateandTime )
			throws JSONException {
		BaseReponse baseReponse= new BaseReponse();
		List<Carpool> carpoolList=null;
		try
		{
		 logger.info("Inside Search Cab");
		 carpoolList=service.searchCab(startPoint,endpoint,dateandTime);
		 if(carpoolList.size()==0)
		 {
			 baseReponse.setReponse("No Cabs Avaialble");	 
		 }
		 else{
		 baseReponse.setCarpoolList(carpoolList);
		 }
		}
		catch(Exception e)
		{
			logger.error("Inside  Exception while seraching");
			baseReponse.setReponse("error while seraching");
		}
		return baseReponse;
		 
	}
	
	@PostMapping(CarpoolConstants.BookCab)
	public BaseReponse BookCab(@RequestParam("userId") String userId, @RequestParam("StartLocation") String startPoint,
			@RequestParam("endLocation") String endpoint,@RequestParam("DateandTime") Date dateandTime )
			throws JSONException {
		BaseReponse baseReponse= new BaseReponse();
		List<Carpool> carpoolList=null;
		try
		{
		 logger.info("Inside Book Cab");
		
		 // Interface to Book The Cab 
		}
		catch(Exception e)
		{
			logger.error("Inside  Exception while Booking");
			baseReponse.setReponse("error while Booking the cab");
		}
		return baseReponse;
		 
	}
	@PostMapping(CarpoolConstants.CancelTrip)
	public BaseReponse CancelTrip(@RequestParam("userId") String userId, Long Requestid,@RequestParam("DateandTime") Date dateandTime )
			throws JSONException {
		BaseReponse baseReponse= new BaseReponse();
		try
		{
		 logger.info("Inside Book Cab");
		
		 // Interface  API call  to cancel the Cab with required  Details 
		}
		catch(Exception e)
		{
			logger.error("Inside  Exception while canceling");
			baseReponse.setReponse("error while Cancelling");
		}
		return baseReponse;
		 
	}
}
