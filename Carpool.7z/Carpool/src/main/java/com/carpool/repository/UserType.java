package com.carpool.repository;

public enum UserType{Driver, Passenger, Both}