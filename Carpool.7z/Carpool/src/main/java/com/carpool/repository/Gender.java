package com.carpool.repository;

public enum Gender{Female ,Male, Other}