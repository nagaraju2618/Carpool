package com.carpool.repository;

import java.io.Serializable;



public class Feedback implements Serializable
{
    public static final int MAX_SCORE = 5;
    public static final int MIN_SCORE = 1;

    private String commenter_id;
    private String receiver_id;
    private String receiver_name;
    private int good_driver;
    private int reliable;
    private int on_time;
	public String getCommenter_id() {
		return commenter_id;
	}
	public void setCommenter_id(String commenter_id) {
		this.commenter_id = commenter_id;
	}
	public String getReceiver_id() {
		return receiver_id;
	}
	public void setReceiver_id(String receiver_id) {
		this.receiver_id = receiver_id;
	}
	public String getReceiver_name() {
		return receiver_name;
	}
	public void setReceiver_name(String receiver_name) {
		this.receiver_name = receiver_name;
	}
	public int getGood_driver() {
		return good_driver;
	}
	public void setGood_driver(int good_driver) {
		this.good_driver = good_driver;
	}
	public int getReliable() {
		return reliable;
	}
	public void setReliable(int reliable) {
		this.reliable = reliable;
	}
	public int getOn_time() {
		return on_time;
	}
	public void setOn_time(int on_time) {
		this.on_time = on_time;
	}
	public static int getMaxScore() {
		return MAX_SCORE;
	}
	public static int getMinScore() {
		return MIN_SCORE;
	}
    
    
}
