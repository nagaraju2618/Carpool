package com.carpool.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
@RepositoryRestResource(path = "Feedback", collectionResourceRel = "Feedback")
public interface FeedBackRepository extends JpaRepository<Feedback, Long>{
		
	// Here we have to write our queires based on requirement			
}
