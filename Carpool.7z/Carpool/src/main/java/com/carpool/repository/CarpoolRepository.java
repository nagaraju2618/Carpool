package com.carpool.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;



@RepositoryRestResource(path = "Carpool", collectionResourceRel = "Carpool")
public interface CarpoolRepository extends PagingAndSortingRepository<Carpool, Long>{
	
	
	@Query("from Carpool where startlocation=:startlocation and endlocation=:endlcoation and startDate=:startdate")
	public List<Carpool> fetchAvialbleCars(@Param("startlocation") String startlocation,@Param("endlocation") String endlcoation,@Param("startDate") Date startdate);
}
