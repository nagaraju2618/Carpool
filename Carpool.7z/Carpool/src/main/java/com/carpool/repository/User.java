package com.carpool.repository;

import java.io.Serializable;
import java.util.ArrayList;

public class User implements Serializable
{
    private String firstName;
    private String lastName;
    private String USER_NAME;
    private String email;
    private String password;
    private Gender gender;
    private UserType userType;
    private String phone;
    private ArrayList<Carpool> carpools;
    private ArrayList<Feedback> feedback;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUSER_NAME() {
		return USER_NAME;
	}
	public void setUSER_NAME(String uSER_NAME) {
		USER_NAME = uSER_NAME;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public UserType getUserType() {
		return userType;
	}
	public void setUserType(UserType userType) {
		this.userType = userType;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public ArrayList<Carpool> getCarpools() {
		return carpools;
	}
	public void setCarpools(ArrayList<Carpool> carpools) {
		this.carpools = carpools;
	}
	public ArrayList<Feedback> getFeedback() {
		return feedback;
	}
	public void setFeedback(ArrayList<Feedback> feedback) {
		this.feedback = feedback;
	}
    
    
  

    
}
