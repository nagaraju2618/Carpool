package com.carpool.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.carpool.repository.Carpool;
import com.carpool.repository.CarpoolRepository;

public class CarpoolDao {
	@Autowired
	CarpoolRepository repository;
	
	public List<Carpool> searchCab(String startpoint,String endpoint, Date dateandTime)
	{
	 return repository.fetchAvialbleCars(startpoint, endpoint, dateandTime);
	
	}
}
