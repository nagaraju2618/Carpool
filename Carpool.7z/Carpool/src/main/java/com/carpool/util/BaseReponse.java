package com.carpool.util;

import java.util.List;

import com.carpool.repository.Carpool;

public class BaseReponse {
	
	private String reponse=null;
	private List<Carpool> carpoolList=null;
	public String getReponse() {
		return reponse;
	}

	public void setReponse(String reponse) {
		this.reponse = reponse;
	}

	public List<Carpool> getCarpoolList() {
		return carpoolList;
	}

	public void setCarpoolList(List<Carpool> carpoolList) {
		this.carpoolList = carpoolList;
	}

	
	
	

}
