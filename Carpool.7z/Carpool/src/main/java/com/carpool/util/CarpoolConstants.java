package com.carpool.util;

public class CarpoolConstants {
	
	public static final String	SEARCHCAB="/searchCab";
	public static final String	BookCab="/bookCab";
	public static final String	TripFeedBack="/tripFeedBack";
	public static final String	CancelTrip="/cancelTrip";

}
