package com.carpool.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.carpool.dao.CarpoolDao;
import com.carpool.repository.Carpool;

public class CarpoolServcie {
	
	@Autowired
	CarpoolDao dao;
	
	
	public List<Carpool> searchCab(String startpoint,String endpoint, Date dateandTime)
	{
	 return dao.searchCab(startpoint, endpoint, dateandTime);	
	}

}
